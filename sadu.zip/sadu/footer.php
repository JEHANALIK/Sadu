<!DOCTYPE html>
<html lang="\" dir="ltr">
  <head>
    <meta charset="utf-8">
    <!-- Required meta tags -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE-edge">
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" media="mediatype and|not|only (expressions)" href="style.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- Bootstrap CSS -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
		integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
	<!-- font -->
	<link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
    <title></title>
  </head>
  <body>
    <nav>
      <div class="sado" style="font-size:0">
      <img src="sadof.png" alt="">
      <img src="sadof.png" alt="">
      <img src="sadof.png" alt="">
      <img src="sadof.png" alt="">
      </div>
    
    </nav>
    <div class="footer-basic">
      <footer class="site-footer">
          <div class="container">
            <div class="row">
            <div class="col-lg-12 ">
              <div class="logo">
                <a href="new.html"> <img src="sado.png" alt=""> </a>
              </div>
          </div>
         </div>

        <div class="row ">
          <div class="col-lg-9 col-md-12 col-sm-12 mt-3 ">
            <h6 style="font-family:serif">About us </h6>
            <p class="text-justify" style="font-family:serif">Sadu Kashta is a website where you can explorem browse all the kashta's that are available in Bahrain and reserve the desired kashta that you like.</p>
          </div>
          <div class="col-lg-9 col-md-12 col-sm-12 mt-3 ">
            <h6 style="font-family:serif">Contac tUs </h6>
          <div class="social">
             <a href="#" style="font-family:serif font-size:22px";>  <i class="fa fa-phone"> </i> 00-973-37345710 </a> <br>
             <a href="#" style="font-family:serif font-size:22px";> <i class="fa fa-envelope"> </i> sado.12@gmail.com</a><br> <br>
             <a href="#" style="font-family:serif font-size:22px";> <i class="fa fa-instagram " ></i> </a>
             <a href="#" style="font-family:serif font-size:22px";> <i class="fa fa-twitter " ></i> </a>
            <a href="#" style="font-family:serif font-size:22px";> <i class="fa fa-facebook" ></i>  </a>
          </div>
      </div>
              <div class="col-lg-3 col-md-3 col-sm-12  mt-4">
                <h6 style="font-family:serif" >Quick Links </h6>
                <div class="footer-links" >
                  <a href="profile.php" style="font-family:serif">Your Profile</a> <br>
                  <a href="login.php" style="font-family:serif">Login</a> <br>
                 
                </div>
             </div>
          </div>
       <hr>
    </div>
            <div class="row">
              <div class=" col-md-12 col-sm-6">
                <p class="copyright-text" style="font-family:serif">Copyright &copy; 2022  </p>
            </div>
          </div>
    </footer>
  </body>
</html>
