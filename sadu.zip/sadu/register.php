<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="register.css">
    <title>Form Validator</title>
  </head>
  <body>
    <div class="container">
      <form id="form" class="form" method="post" action="insert.php">
        <h2>Register With Us</h2>
        <div class="form-control">
          <label for="username">Username</label>
          <input type="text" id="username" name="un" placeholder="Enter username" />
          <small>Error message</small>
        </div>
        <div class="form-control">
          <label for="email">Email</label>
          <input type="text" id="email"  name="em" placeholder="Enter email" />
          <small>Error message</small>
        </div>
        <div class="form-control">
          <label for="password">Password</label>
          <input type="password" id="password" name="ps" placeholder="Enter password" />
          <small>Error message</small>
        </div>
        <div class="form-control">
          <label for="password2">Confirm Password</label>
          <input
            type="password"id="password2" name="cps"  placeholder="Enter password again"  />
          <small>Error message</small>
        </div>

        <div class="form-control">
          <label for="password2">phone Number</label>
          <input
            type="text"id="phone" name="pn"  placeholder="Enter your phone number"  />
          <small>Error message</small>
        </div>
        <button type="submit">Submit</button>
      </form>
    </div>




    <script src="script.js"></script>
  </body>
</html>
